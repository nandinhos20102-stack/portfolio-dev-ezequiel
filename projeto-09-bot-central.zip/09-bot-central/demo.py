modulos=['pesquisa','CNAE','cotação','fornecedores','PDF','notificações','sessão']
print('Módulos:',', '.join(modulos))
print('Ação final: revisão humana')
