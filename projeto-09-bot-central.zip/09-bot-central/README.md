# Bot central de licitações
Protótipo que reúne atalhos dos módulos de pesquisa, cotação e revisão.
