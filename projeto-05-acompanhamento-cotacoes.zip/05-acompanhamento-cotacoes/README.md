# Bot de acompanhamento de cotações
Protótipo de painel textual para status de cotações.
