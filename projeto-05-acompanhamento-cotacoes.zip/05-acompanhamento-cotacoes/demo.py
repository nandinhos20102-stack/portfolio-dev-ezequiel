status={'DEMO-001':'aguardando revisão','DEMO-002':'cotação recebida'}
for codigo,valor in status.items(): print(codigo,valor)
