# Portfólio - Ezequiel Prestes da Silva

Projetos demonstrativos para candidatura a vagas de desenvolvimento web, automação e suporte técnico.

## Projetos

- `01-site-responsivo`: landing page responsiva em HTML, CSS e JavaScript.
- `02-automacao-arquivos`: organização automática de arquivos por extensão em Python.
- `03-painel-ia-demo`: painel web simples para registrar tarefas e simular um fluxo de automação.

Cada pasta possui seu próprio README com instruções de execução.
