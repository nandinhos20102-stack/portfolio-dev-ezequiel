# Painel de automação

Dashboard front-end demonstrativo para acompanhar tarefas automatizadas e comunicar status ao usuário.

## Como executar

Abra `index.html` no navegador.
