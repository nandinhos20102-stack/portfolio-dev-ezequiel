# Site responsivo

Landing page demonstrativa feita com HTML, CSS e JavaScript puro.

## Como executar

Abra `index.html` no navegador.
