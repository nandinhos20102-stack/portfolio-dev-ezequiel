# Automação de arquivos

Script Python que separa arquivos por categoria e cria as pastas necessárias automaticamente.

## Como executar

```bash
python organizar_arquivos.py
```

O projeto demonstra leitura de diretórios, tratamento de extensões, criação de pastas e movimentação de arquivos.
