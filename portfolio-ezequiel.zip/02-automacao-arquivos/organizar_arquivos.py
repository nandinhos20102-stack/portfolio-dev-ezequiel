from pathlib import Path
import shutil

CATEGORIAS = {
    'imagens': {'.png', '.jpg', '.jpeg', '.gif'},
    'documentos': {'.pdf', '.docx', '.txt', '.xlsx'},
    'compactados': {'.zip', '.rar', '.7z'},
}

def organizar(pasta: str) -> dict:
    raiz = Path(pasta).expanduser().resolve()
    resumo = {}
    for arquivo in raiz.iterdir():
        if not arquivo.is_file():
            continue
        categoria = next((nome for nome, extensoes in CATEGORIAS.items() if arquivo.suffix.lower() in extensoes), 'outros')
        destino = raiz / categoria
        destino.mkdir(exist_ok=True)
        shutil.move(str(arquivo), str(destino / arquivo.name))
        resumo[categoria] = resumo.get(categoria, 0) + 1
    return resumo

if __name__ == '__main__':
    pasta = input('Pasta para organizar: ').strip()
    print('Arquivos organizados:', organizar(pasta))
