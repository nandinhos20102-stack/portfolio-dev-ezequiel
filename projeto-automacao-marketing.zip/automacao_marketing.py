import csv
from pathlib import Path

ETAPAS = {
    'novo': 'Boas-vindas',
    'interessado': 'Enviar conteúdo',
    'cliente': 'Pedir avaliação',
}

def criar_fila(caminho_csv: str):
    fila = []
    with Path(caminho_csv).open(newline='', encoding='utf-8') as arquivo:
        for contato in csv.DictReader(arquivo):
            etapa = contato.get('etapa', 'novo').strip().lower()
            fila.append({
                'email': contato.get('email', '').strip(),
                'segmento': etapa,
                'acao': ETAPAS.get(etapa, 'Revisar segmento'),
            })
    return fila

if __name__ == '__main__':
    arquivo = Path(__file__).with_name('contatos_exemplo.csv')
    print('Fila de marketing:')
    for item in criar_fila(str(arquivo)):
        print(f"- {item['email']}: {item['acao']}")
