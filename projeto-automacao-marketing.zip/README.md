# Automação de marketing

Projeto Python demonstrativo que lê uma lista de contatos, segmenta cada pessoa pela etapa do funil e cria uma fila de próxima ação.

## Executar

```bash
python automacao_marketing.py
```

O CSV usa apenas contatos fictícios. Em um produto real, a fila poderia alimentar e-mail, CRM ou uma API de mensagens, respeitando consentimento e regras de privacidade.
