oportunidades=['DEMO-001 — materiais de escritório','DEMO-002 — manutenção web']
for oportunidade in oportunidades: print('NOTIFICAÇÃO:',oportunidade)
