# Bot de notificações de oportunidades
Protótipo que gera notificações locais a partir de dados fictícios.
