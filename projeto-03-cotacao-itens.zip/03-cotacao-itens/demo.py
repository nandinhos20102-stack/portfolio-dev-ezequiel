item=input('Item: ')
ofertas=[('Fornecedor Demo A',100),('Fornecedor Fictício B',120)]
print(item, sorted(ofertas,key=lambda x:x[1]))
