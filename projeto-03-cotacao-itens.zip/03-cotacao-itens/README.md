# Bot de cotação de itens
Protótipo que organiza cotações fictícias para revisão manual.
