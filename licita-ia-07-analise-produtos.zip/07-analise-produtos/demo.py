produto={'nome':'Notebook Demo','categoria':'informática','atributos':['16GB RAM','SSD']}; print(produto)
