# Licita IA — análise de produtos
Extrai características de produtos fictícios para comparação.
