# API de chamados de suporte

API REST mínima, feita apenas com a biblioteca padrão do Python, para registrar e consultar chamados de suporte.

## Executar

```bash
python api_chamados.py
```

## Rotas

- `GET /chamados` lista chamados.
- `POST /chamados` cria um chamado com JSON, por exemplo: `{"titulo":"Acesso bloqueado"}`.
