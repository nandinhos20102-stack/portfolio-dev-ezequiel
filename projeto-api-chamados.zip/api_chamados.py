from http.server import BaseHTTPRequestHandler, HTTPServer
import json

chamados = []

class Handler(BaseHTTPRequestHandler):
    def _responder(self, status, payload):
        corpo = json.dumps(payload, ensure_ascii=False).encode('utf-8')
        self.send_response(status)
        self.send_header('Content-Type', 'application/json; charset=utf-8')
        self.send_header('Content-Length', str(len(corpo)))
        self.end_headers()
        self.wfile.write(corpo)

    def do_GET(self):
        if self.path == '/chamados':
            self._responder(200, chamados)
        else:
            self._responder(404, {'erro': 'Rota não encontrada'})

    def do_POST(self):
        if self.path != '/chamados':
            self._responder(404, {'erro': 'Rota não encontrada'})
            return
        tamanho = int(self.headers.get('Content-Length', 0))
        dados = json.loads(self.rfile.read(tamanho) or '{}')
        chamado = {'id': len(chamados) + 1, 'titulo': dados.get('titulo', 'Sem título'), 'status': 'aberto'}
        chamados.append(chamado)
        self._responder(201, chamado)

if __name__ == '__main__':
    print('API disponível em http://localhost:8000')
    HTTPServer(('localhost', 8000), Handler).serve_forever()
