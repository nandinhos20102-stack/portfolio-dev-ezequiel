texto='edital demonstrativo'; print({'entrada':texto,'status':'aguardando modelo autorizado'})
