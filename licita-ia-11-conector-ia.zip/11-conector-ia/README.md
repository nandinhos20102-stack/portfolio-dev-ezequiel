# Licita IA — conector de inteligência artificial
Demonstração de encaminhamento de texto para uma etapa de análise simulada.
