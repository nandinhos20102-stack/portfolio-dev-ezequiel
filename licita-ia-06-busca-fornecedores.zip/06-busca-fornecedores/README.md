# Licita IA — busca de fornecedores
Busca demonstrativa em cadastro de fornecedores fictícios.
