print({'nome':'Fornecedor Demo','categoria':'informática','fonte':'cadastro fictício'})
