arquivo='edital_demo.pdf'
resumo='Resumo fictício: conferir prazos, requisitos e documentos.'
print(arquivo,resumo)
