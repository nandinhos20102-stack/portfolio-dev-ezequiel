# Bot de leitura de PDFs de licitações
Protótipo que representa a etapa de resumo de um PDF para validação humana.
