# Licita IA — apoio em sessões de pregão
Checklist demonstrativo para apoio humano, sem envio automático de lances.
