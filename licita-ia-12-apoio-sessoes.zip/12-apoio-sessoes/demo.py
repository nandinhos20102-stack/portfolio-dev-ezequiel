print(['ler regras','validar proposta','acompanhar horário','decisão humana'])
