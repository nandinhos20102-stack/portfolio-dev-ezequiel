valores=[100,120,110]; print({'menor':min(valores),'media':sum(valores)/len(valores)})
