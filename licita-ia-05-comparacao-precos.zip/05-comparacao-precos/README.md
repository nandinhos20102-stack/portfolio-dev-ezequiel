# Licita IA — comparação de preços
Compara valores fictícios sem recomendar compra automaticamente.
