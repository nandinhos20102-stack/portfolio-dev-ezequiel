print([e for e in ['DEMO-001 materiais','DEMO-002 manutenção'] if 'manutenção' in e])
