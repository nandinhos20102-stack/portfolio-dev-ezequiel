# Bloco de notas

Aplicação web de notas feita com HTML, CSS e JavaScript puro.

## Recursos

- Criar, editar e excluir notas;
- Busca por título ou conteúdo;
- Salvamento automático no `localStorage`;
- Modo claro e escuro;
- Layout responsivo.

## Como executar

Abra `index.html` no navegador. Os dados ficam salvos apenas no navegador local.
