# Licita IA — análise de editais relevantes
Protótipo de classificação de relevância com revisão humana.
