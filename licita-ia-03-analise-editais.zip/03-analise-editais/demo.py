edital={'codigo':'DEMO-001','relevancia':0.86,'revisao_humana':True}; print(edital)
