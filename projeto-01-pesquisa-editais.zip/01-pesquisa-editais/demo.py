editais=[{'id':'DEMO-001','objeto':'materiais de escritório'},{'id':'DEMO-002','objeto':'manutenção web'}]
termo=input('Termo: ').lower()
print([e for e in editais if termo in e['objeto']])
