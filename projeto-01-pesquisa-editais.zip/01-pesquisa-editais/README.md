# Bot de pesquisa de editais
Protótipo offline para pesquisar editais fictícios por palavra-chave.
