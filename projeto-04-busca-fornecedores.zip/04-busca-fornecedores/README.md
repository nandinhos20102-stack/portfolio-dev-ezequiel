# Bot de busca de fornecedores
Protótipo offline com cadastro de fornecedores fictícios.
