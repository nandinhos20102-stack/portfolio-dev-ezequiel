fornecedor={'nome':'Fornecedor Demo A','categorias':['web','informática'],'fonte':'cadastro fictício'}
print(fornecedor)
