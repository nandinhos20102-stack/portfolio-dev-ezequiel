editais=[('DEMO-001','47.61-0'),('DEMO-002','62.01-5')]
cnae=input('CNAE: ')
print([e for e in editais if e[1]==cnae])
