# Bot de análise por CNAE
Protótipo offline que filtra oportunidades fictícias por CNAE.
