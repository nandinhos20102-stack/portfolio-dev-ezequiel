import csv
from pathlib import Path

def pontuar(registro):
    pontos = 0
    if registro['segmento'].lower() in {'tecnologia', 'servicos'}: pontos += 3
    if registro['interesse'].lower() == 'alto': pontos += 3
    if float(registro['orcamento']) >= 3000: pontos += 2
    if registro['origem'].lower() in {'evento', 'indicacao'}: pontos += 1
    return pontos

def garimpar(caminho):
    with Path(caminho).open(encoding='utf-8', newline='') as arquivo:
        dados = list(csv.DictReader(arquivo))
    return sorted(dados, key=pontuar, reverse=True)

if __name__ == '__main__':
    resultados = garimpar(Path(__file__).with_name('oportunidades_exemplo.csv'))
    for item in resultados:
        print(f"{pontuar(item)} pontos | {item['empresa']} | Próxima ação: {item['proxima_acao']}")
