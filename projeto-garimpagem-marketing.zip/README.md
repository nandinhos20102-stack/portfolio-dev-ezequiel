# Garimpagem de oportunidades de marketing

Projeto Python que lê uma base fictícia de oportunidades, calcula uma pontuação por critérios de segmento, interesse, orçamento e origem, e gera uma fila priorizada de ações comerciais.

## Executar

```bash
python garimpar_oportunidades.py
```

Os dados são totalmente fictícios. Em uso real, a coleta deve respeitar autorização, termos de uso e legislação de privacidade.
