# Licita IA — filtro por CNAE
Filtro demonstrativo de oportunidades fictícias por CNAE.
