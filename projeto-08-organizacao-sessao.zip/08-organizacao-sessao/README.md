# Bot de organização de sessões
Protótipo de checklist para acompanhar uma sessão, sem enviar lances.
