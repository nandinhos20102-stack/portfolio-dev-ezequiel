etapas=['ler edital','validar requisitos','revisar proposta','decisão humana']
print('\n'.join('□ '+etapa for etapa in etapas))
