"""Protótipo offline de modelos de bots para licitações.

Os registros abaixo são fictícios e servem apenas para demonstrar arquitetura.
"""
from dataclasses import dataclass
from datetime import date


@dataclass
class Edital:
    codigo: str
    orgao: str
    objeto: str
    cnae: str
    prazo: str
    status: str = "aberto"


EDITAIS = [
    Edital("DEMO-001", "Prefeitura Exemplo", "Materiais de escritório", "47.61-0", "2026-11-20"),
    Edital("DEMO-002", "Instituto Fictício", "Serviços de manutenção web", "62.01-5", "2026-11-25"),
]


def pesquisar_editais(termo: str = ""):
    return [e for e in EDITAIS if termo.lower() in (e.objeto + e.orgao).lower()]


def filtrar_cnae(cnae: str):
    return [e for e in EDITAIS if e.cnae == cnae]


def cotar_item(item: str):
    return {"item": item, "fornecedores": ["Fornecedor Demo A", "Fornecedor Fictício B"], "revisão": "manual"}


def buscar_fornecedores(item: str):
    return [{"nome": "Fornecedor Demo A", "item": item, "fonte": "cadastro fictício"}]


def acompanhar_cotacoes():
    return [{"edital": "DEMO-001", "status": "aguardando revisão", "atualizado": str(date.today())}]


def resumir_pdf(nome: str):
    return {"arquivo": nome, "resumo": "Documento fictício aguardando leitura e validação humana."}


def notificar_oportunidades():
    return [f"Nova oportunidade: {e.codigo} — {e.objeto}" for e in EDITAIS if e.status == "aberto"]


def organizar_sessao():
    return {"sessão": "DEMO-001", "etapas": ["ler edital", "validar requisitos", "revisar proposta", "decisão humana"]}


def main():
    print("=== Licita IA / Bots Discord — demonstração offline ===")
    print("Pesquisa:", [e.codigo for e in pesquisar_editais("web")])
    print("Filtro CNAE:", [e.codigo for e in filtrar_cnae("62.01-5")])
    print("Cotação:", cotar_item("notebook"))
    print("Fornecedores:", buscar_fornecedores("notebook"))
    print("Acompanhamento:", acompanhar_cotacoes())
    print("PDF:", resumir_pdf("edital_demo.pdf"))
    print("Notificações:", notificar_oportunidades())
    print("Sessão:", organizar_sessao())


if __name__ == "__main__":
    main()
