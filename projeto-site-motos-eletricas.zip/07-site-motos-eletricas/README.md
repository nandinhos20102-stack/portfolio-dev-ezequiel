# Site de motos elétricas

Landing page responsiva para uma marca fictícia de mobilidade elétrica, criada para demonstrar HTML, CSS e JavaScript.

## Recursos

- Hero section com chamada comercial;
- Cards de modelos e comparação rápida;
- Formulário interativo de interesse;
- Layout adaptado para celular;
- Dados e marca fictícios, sem finalidade comercial real.

## Como executar

Abra `index.html` no navegador.
