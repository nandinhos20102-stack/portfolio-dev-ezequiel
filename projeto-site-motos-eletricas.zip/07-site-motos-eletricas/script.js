const form=document.querySelector('#interestForm');
document.querySelectorAll('.card-btn').forEach(btn=>btn.addEventListener('click',()=>{document.querySelector('#model').value=btn.dataset.model;document.querySelector('#contato').scrollIntoView({behavior:'smooth'});}));
document.querySelector('#compare').addEventListener('click',()=>alert('Urban S: 100 km | City Pro: 150 km | Street One: 70 km de autonomia.'));
form.addEventListener('submit',e=>{e.preventDefault();document.querySelector('#formMessage').textContent='Obrigado! Sua demonstração foi registrada neste protótipo.';form.reset();});
