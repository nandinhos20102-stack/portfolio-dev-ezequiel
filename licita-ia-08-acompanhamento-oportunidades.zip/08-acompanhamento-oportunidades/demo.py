print({'DEMO-001':'em análise','DEMO-002':'aguardando prazo'})
