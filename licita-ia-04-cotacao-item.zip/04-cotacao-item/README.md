# Licita IA — cotação item por item
Organiza ofertas fictícias por item para análise manual.
