print(sorted([{'fornecedor':'Demo A','preco':100},{'fornecedor':'Demo B','preco':120}],key=lambda x:x['preco']))
