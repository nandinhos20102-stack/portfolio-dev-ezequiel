# Licita IA — integração com WhatsApp
Modelo de fila de notificações; não envia mensagens reais.
