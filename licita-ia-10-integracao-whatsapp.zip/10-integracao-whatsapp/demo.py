fila=[{'canal':'WhatsApp Business','mensagem':'Oportunidade DEMO-001','autorizacao':False}]; print(fila)
