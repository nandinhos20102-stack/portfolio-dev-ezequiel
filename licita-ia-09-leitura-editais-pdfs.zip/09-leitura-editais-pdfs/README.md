# Licita IA — leitura de editais e PDFs
Protótipo de resumo de documento com validação humana.
